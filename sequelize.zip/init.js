import Sequelize from "sequelize";
const { DataTypes } = Sequelize;

const sequelize = new Sequelize({
  dialect: "sqlite",
  storage: "./data/database.sqlite",
  //  logging: false,
});

/*
const sequelize = new Sequelize('adatbazis_neve', 'felhasznalonev', 'jelszo', { 
  host: 'localhost', 
  dialect: 'mysql', // vagy 'postgres', 'sqlite', stb.
  //  logging: false,
});  
*/
const Students = sequelize.define(
	"students",
	{
		student_id: {
			type: DataTypes.INTEGER,
			primaryKey: true,
			autoIncrement: true,
		},
		name: {
			type: DataTypes.STRING,
			allowNull: false,
			validate: {
				min: 4,
                max: 20
			}
		},
		favorite_class: {
			type: DataTypes.STRING,
			defaultValue: "Computer Science",
		},
        school_year: {
            type: DataTypes.INTEGER,
            allowNull:false
        },
        has_language_examination: {
            type: DataTypes.BOOLEAN,
            defaultValue: true
        }
	},
	{
		// Optional - Options
		freezeTableName: true,
	}
);
//console.log(sequelize.models.students)

Students.sync({force:  true})
            .then((data) => {
                console.log("Table and model synced successful");
            })
            .catch((err) => {
                console.log("Error syncing the table and model");
            });
//adding data

Students.sync()
            .then(()=>{
                return Students.bulkCreate([
                    {name: "Csaba", favorite_class: "Computer Science", school_year: 13, has_language_examination: true},
                    {name: "Miklós", favorite_class: "History", school_year: 13, has_language_examination: true},
                    {name: "Vivien", favorite_class: "Computer Science", school_year: 12, has_language_examination: true},
                    {name: "Sándor", favorite_class: "Computer Science", school_year: 13, has_language_examination: false},
                    {name: "Katalin", favorite_class: "Mathematics", school_year: 12, has_language_examination: false}
                ])
            })


//query time
//get all students whose fav class is CS or has lang cert
Students.sync()
            .then(()=>{
                return Students.findAll({
                    attributes: ["name"],
                    where: Sequelize.or(
                        {favorite_class: "Computer Science"},
                        {has_language_examination: true}
                    )
                })
            })
            .then((data) => {
                data.forEach((element) => {
                    console.log(element.toJSON());
                });
            })
            .catch((err) => {
                console.log(`Error: ${err.message}`);
            });
//which classes have how many students
Students.sync()
            .then(()=>{
                return Students.findAll({
                    attributes: 
                    [
                        "school_year", 
                        [sequelize.fn("COUNT", sequelize.col("name")), "num_students"] 
                    ],
                    group: "school_year"
                })
            })
            .then((data) => {
                data.forEach((element) => {
                    console.log(element.toJSON());
                });
            })
            .catch((err) => {
                console.log(`Error: ${err.message}`);
            });
        

